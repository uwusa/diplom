const slider = document.getElementById("slider");
const arrowLeft = document.querySelector(".arrow-left");
const arrowRight = document.querySelector(".arrow-right");
const slides = document.querySelectorAll(".slider-image");

let currentSlideIndex = 0;
let currentSlide = 0;
const paginationCircles = [];
const sliderWidth = slider.clientWidth;
let autoSlideInterval;
function moveSlide(direction) {
    const slides = document.querySelectorAll('.slider-image');
    const totalSlides = slides.length;

    // Обновляем текущий слайд
    currentSlide = (currentSlide + direction + totalSlides) % totalSlides;

    // Сдвигаем слайдер
    const slider = document.getElementById('slider');
    slider.style.transform = `translateX(-${currentSlide * 100}%)`;

    // Обновляем пагинацию
    updatePagination();
}

function setSlide(index) {
    currentSlide = index;
    const slider = document.getElementById('slider');
    slider.style.transform = `translateX(-${currentSlide * 100}%)`;
    updatePagination();
}

function updatePagination() {
    const circles = document.querySelectorAll('.pagination-circle');
    circles.forEach((circle, index) => {
        circle.classList.remove('active');
        if (index === currentSlide) {
            circle.classList.add('active');
        }
    });
}
function createPaginationCircle() {
    const div = document.createElement("div");
    div.className = "pagination-circle";
    bottom.appendChild(div);
    paginationCircles.push(div);
}

function addPagination() {
    slides.forEach(createPaginationCircle);
    paginationCircles[0].classList.add("active");
    paginationCircles.forEach((circle, index) => {
        circle.addEventListener("click", () => {
            changeSlide(index);
            resetAutoSlide(); // Сбросить автоматическую ротацию при ручном переключении
        });
    });
}

function addActiveClass() {
    paginationCircles[currentSlideIndex].classList.add("active");
}

function removeActiveClass() {
    paginationCircles[currentSlideIndex].classList.remove("active");
}

function showSlide() {
    slider.style.transform = `translateX(-${currentSlideIndex * sliderWidth}px)`;
}

function changeSlide(slideIndex) {
    removeActiveClass();
    currentSlideIndex = slideIndex;
    addActiveClass();
    showSlide();
}

function nextSlide() {
    let newSlideIndex = currentSlideIndex + 1;
    if (newSlideIndex > slides.length - 1) {
        newSlideIndex = 0;
    }
    changeSlide(newSlideIndex);
}

function previousSlide() {
    let newSlideIndex = currentSlideIndex - 1;
    if (newSlideIndex < 0) {
        newSlideIndex = slides.length - 1;
    }
    changeSlide(newSlideIndex);
}

function startAutoSlide() {
    autoSlideInterval = setInterval(nextSlide, 3000); // Менять слайд каждые 3 секунды
}

function resetAutoSlide() {
    clearInterval(autoSlideInterval);
    startAutoSlide(); // Перезапустить автоматическую ротацию
}

// Остановка автоматической ротации при наведении
function stopAutoSlide() {
    clearInterval(autoSlideInterval);
}

// Восстановление автоматической ротации при уходе курсора
function resumeAutoSlide() {
    startAutoSlide();
}

// Инициализация
addPagination();
arrowLeft.addEventListener("click", previousSlide);
arrowRight.addEventListener("click", nextSlide);
startAutoSlide(); // Запуск автоматической ротации

// Добавление обработчиков событий для остановки и возобновления ротации
slider.addEventListener("mouseover", stopAutoSlide);
slider.addEventListener("mouseout", resumeAutoSlide);

function openModal(modalId) {
    document.getElementById(modalId).style.display = "block";
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

function clearForm() {
    document.getElementById("registrationForm").reset();
}

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
